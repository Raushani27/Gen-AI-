

# 1. Create the products list
products = [
    "Laptop", "Phone", "Headphones", "Keyboard",
    "Mouse", "Monitor", "Tablet", "Smartwatch"
]

# Define price_dict
price_dict = {
    "Laptop": 55000,
    "Phone": 22000,
    "Headphones": 2500,
    "Keyboard": 1500,
    "Mouse": 800,
    "Monitor": 12000,
    "Tablet": 18000,
    "Smartwatch": 5000
}

# Define categories matching the products list
categories = [
    "Electronics", "Electronics", "Accessories", "Accessories",
    "Accessories", "Electronics", "Electronics", "Wearables"
]

# 2. Create a list of tuples named catalog
# Each tuple is (product_name, price, category)
catalog = []

for i in range(len(products)):
    product_name = products[i]
    price = price_dict[product_name]
    category = categories[i]

    catalog.append((product_name, price, category))

print("Product catalog:")
for item in catalog:
    print(item)

# 3. Create a dictionary mapping categories to product names
category_to_products = {}

for product_name, price, category in catalog:
    if category not in category_to_products:
        category_to_products[category] = []

    category_to_products[category].append(product_name)

print("\nCategory to products:")
print(category_to_products)

# 4. Print products belonging to the category with the most products
largest_category = max(
    category_to_products,
    key=lambda category: len(category_to_products[category])
)

print("\nCategory with the maximum number of products:", largest_category)
print("Products in this category:")

for product in category_to_products[largest_category]:
    print(product)
