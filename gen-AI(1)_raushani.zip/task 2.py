
# 1.list of categories 
categories = [
    "Electronics",
    "Electronics",
    "Electronics",
    "Accessories",
    "Accessories",
    "Electronics",
    "Electronics",
    "Wearables"
]

# Create a set of unique categories
categories_set = set(categories)
print("Categories set:", categories_set)

# 2. Add a new category and demonstrate duplicates are ignored
categories_set.add("Furniture")
categories_set.add("Electronics")   

print("After adding categories:", categories_set)

# 3. Check whether a category exists in the set
print("Is Electronics present?", "Electronics" in categories_set)
print("Is Clothing present?", "Clothing" in categories_set)

# Extra
print("Total unique categories:", len(categories_set))
