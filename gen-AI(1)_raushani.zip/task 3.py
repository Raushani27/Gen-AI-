
# 1. Create a dictionary with product names and prices
price_dict = {
    "Laptop": 55000,
    "Phone": 20000,
    "Headphones": 2500,
    "Keyboard": 1500,
    "Mouse": 800,
    "Monitor": 12000,
    "Tablet": 18000,
    "Smartwatch": 5000
}

print("Product prices:", price_dict)

# 2(a). Add a new product with its price
price_dict["Printer"] = 7500
print("After adding a product:", price_dict)

# 2(b). Update the price of an existing product
price_dict["Phone"] = 22000
print("After updating phone price:", price_dict)

# 2(c). Remove a product by name
product_name = "Mouse"

if product_name in price_dict:
    del price_dict[product_name]
    print(product_name, "removed successfully.")
else:
    print(product_name, "does not exist.")

print("After removing a product:", price_dict)

# 3. Calculate the average price
total_price = sum(price_dict.values())
number_of_products = len(price_dict)

if number_of_products > 0:
    average_price = total_price / number_of_products
    print("Average price:", average_price)
else:
    print("No products available.")

# Extra: Find the products with maximum and minimum prices
if price_dict:
    max_product = max(price_dict, key=price_dict.get)
    min_product = min(price_dict, key=price_dict.get)

    print("Highest-priced product:", max_product, price_dict[max_product])
    print("Lowest-priced product:", min_product, price_dict[min_product])
