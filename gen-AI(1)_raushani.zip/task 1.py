#1 . list 
products = ["Laptop", "Phone", "Headphones", "Keyboard", "Mouse", "Monitor"]
#2. tuple 
sample_product = ("Laptop", 55000, "Electronics")

#3. Print the 2nd and last product
print("Second product:", products[1])
print("Last product:", products[-1])

# 4. Append two new products and print the updated list
products.append("Tablet")
products.append("Smartwatch")
print("Updated products list:", products)

# Extra
product_list = list(sample_product)
product_list[1] = 60000
sample_product = tuple(product_list)

print("Updated sample product:", sample_product)
