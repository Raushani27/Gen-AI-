
# Task 5: Using filter() - Filter Expensive Products

prices = [100, 250, 400, 1200, 50, 2000, 850]

# 1. Prices greater than 500
expensive_prices = list(filter(lambda price: price > 500, prices))

# 2. Prices less than or equal to 500
affordable_prices = list(filter(lambda price: price <= 500, prices))

print("Original prices:", prices)
print("Prices greater than 500:", expensive_prices)
print("Prices less than or equal to 500:", affordable_prices)
