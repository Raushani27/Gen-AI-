
# Task 1: Basic Function - Price After Discount

def apply_discount(price, discount_percent=5):
    # Extra: Ensure discount does not exceed 60%
    if discount_percent > 60:
        discount_percent = 60

    discount = price * discount_percent / 100
    final_price = price - discount

    return final_price


# Test the function
print("Price after 10% discount:", apply_discount(1000, 10))
print("Price after default 5% discount:", apply_discount(500))
