
# Task 3: Lambda Function - GST Calculator

# Calculate price after adding 18% GST
gst = lambda price: price + (0.18 * price)

print(gst(100))

# Extra: Calculate final price after GST and discount
gst_discount = lambda price, discount: (price - (price * discount / 100)) * 1.18

print(gst_discount(1000, 10))
