
# Task 4: Using map() - Apply GST to List of Prices

prices = [100, 250, 400, 1200, 50]

# Apply 18% GST to every price
prices_with_gst = list(map(lambda price: price * 1.18, prices))

print("Original prices:", prices)
print("Prices after GST:", prices_with_gst)
