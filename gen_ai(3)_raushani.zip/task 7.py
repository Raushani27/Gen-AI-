
# Task 7: Mini Problem - Menu Using Functions

# 1. Add a price to the list
def add_price(prices_list, price):
    prices_list.append(price)


# 2. Calculate the average price
def get_average_price(prices_list):
    if len(prices_list) == 0:
        return 0

    total = 0

    for price in prices_list:
        total = total + price

    return total / len(prices_list)


# 3. Find the maximum price
def get_max_price(prices_list):
    if len(prices_list) == 0:
        return None

    max_price = prices_list[0]

    for price in prices_list:
        if price > max_price:
            max_price = price

    return max_price


# Main menu
prices_list = []

while True:
    print("\n----- PRICE MENU -----")
    print("1 - Add price")
    print("2 - Show average price")
    print("3 - Show highest price")
    print("q - Quit")

    choice = input("Enter your choice: ")

    if choice == "1":
        price_input = input("Enter price: ")

        if price_input.replace(".", "", 1).isdigit():
            price = float(price_input)
            add_price(prices_list, price)
            print("Price added successfully.")
        else:
            print("Invalid price. Please enter a valid number.")

    elif choice == "2":
        if len(prices_list) == 0:
            print("No prices available.")
        else:
            print("Average price:", get_average_price(prices_list))

    elif choice == "3":
        if len(prices_list) == 0:
            print("No prices available.")
        else:
            print("Highest price:", get_max_price(prices_list))

    elif choice == "q":
        print("Exiting program. Goodbye!")
        break

    else:
        print("Invalid choice. Please try again.")
