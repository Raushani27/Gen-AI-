
# Task 6: Combined Utility Function

def process_prices(prices):
    # Apply 10% discount to all prices
    discounted_prices = list(map(lambda price: price * 0.90, prices))

    # Keep only discounted prices above 300
    filtered_prices = list(
        filter(lambda price: price > 300, discounted_prices)
    )

    return discounted_prices, filtered_prices


# Test the function
discounted_prices, filtered_prices = process_prices([100, 500, 900, 50, 750])

print("Discounted prices:", discounted_prices)
print("Filtered prices:", filtered_prices)
