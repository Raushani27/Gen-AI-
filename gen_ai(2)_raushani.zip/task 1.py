
# Task 1: Discount Rules

order_input = input("Enter order amount: ")

if order_input.isdigit():
    order_amount = int(order_input)

    if order_amount >= 2000:
        discount_percent = 15
    elif order_amount >= 1500:
        discount_percent = 10
    elif order_amount >= 1000:
        discount_percent = 7
    else:
        discount_percent = 0

    discount = order_amount * discount_percent / 100
    final_amount = order_amount - discount

    print("Order amount:", order_amount)
    print("Discount:", discount_percent, "%")
    print("Discount amount:", discount)
    print("Final amount:", final_amount)

    # Extra: Calculate 5% tax after discount
    tax = final_amount * 5 / 100
    total = final_amount + tax

    print("Tax (5%):", tax)
    print("Final total including tax:", total)

else:
    print("Error: Please enter a valid non-negative integer.")
