
# Task 2: Process Multiple Orders

orders = [1200, 2500, 800, 1750, 3000]

total_revenue = 0
discounted_orders = 0

print("Order Amount | Discount % | Final Amount")
print("------------------------------------------")

for order_amount in orders:

    if order_amount >= 2000:
        discount_percent = 15
    elif order_amount >= 1500:
        discount_percent = 10
    elif order_amount >= 1000:
        discount_percent = 7
    else:
        discount_percent = 0

    discount = order_amount * discount_percent / 100
    final_amount = order_amount - discount

    print(order_amount, "        |", discount_percent, "%        |", final_amount)

    total_revenue = total_revenue + final_amount

    if discount_percent > 0:
        discounted_orders = discounted_orders + 1

print("------------------------------------------")
print("Total revenue after discounts:", total_revenue)
print("Number of discounted orders:", discounted_orders)
