
# Task 4: Loop Control with Conditions

daily = [200, 150, 0, 400, 50, -1, 300]

total_sales = 0

for sales in daily:

    if sales == -1:
        print("Corrupted data found. Stopping processing.")
        break

    if sales == 0:
        print("No sales today. Skipping.")
        continue

    total_sales = total_sales + sales
    print("Sales:", sales, "| Running total:", total_sales)

print("Final total sales:", total_sales)
