
# Task 3: User Menu

orders = []

while True:
    print("\n----- USER MENU -----")
    print("1 - Add order amount")
    print("2 - Show all orders and totals after discounts")
    print("3 - Quit")

    choice = input("Enter your choice: ")

    if choice == "1":
        order_input = input("Enter order amount: ")

        if not order_input.isdigit():
            print("Invalid amount! Please enter a non-negative integer.")
            continue

        order_amount = int(order_input)
        orders.append(order_amount)
        print("Order added successfully.")

    elif choice == "2":
        if len(orders) == 0:
            print("No orders available.")
            continue

        total_revenue = 0

        print("\nOrder Amount | Discount % | Final Amount")
        print("------------------------------------------")

        for order_amount in orders:
            if order_amount >= 2000:
                discount_percent = 15
            elif order_amount >= 1500:
                discount_percent = 10
            elif order_amount >= 1000:
                discount_percent = 7
            else:
                discount_percent = 0

            discount = order_amount * discount_percent / 100
            final_amount = order_amount - discount

            print(order_amount, "|", discount_percent, "% |", final_amount)
            total_revenue = total_revenue + final_amount

        print("------------------------------------------")
        print("Total revenue after discounts:", total_revenue)

    elif choice == "3":
        print("Exiting program. Goodbye!")
        break

    else:
        print("Invalid choice! Please select 1, 2, or 3.")
        continue
